Archive_004
Classifier training acquisitions: 5
Identifiers and biological channel names were replaced by neutral IDs.
Numeric image/ROI/table values and manual keep/discard decisions are preserved.
