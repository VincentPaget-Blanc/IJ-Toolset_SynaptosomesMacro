Archive_006
Classifier training acquisitions: 9
Identifiers and biological channel names were replaced by neutral IDs.
Numeric image/ROI/table values and manual keep/discard decisions are preserved.
